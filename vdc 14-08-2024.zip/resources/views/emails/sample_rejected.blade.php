<!DOCTYPE html>
<html>
<head>
    <title>Sample  Rejected</title>
</head>
<body>
    <p>Your Sample Booking has been rejected.</p>
</body>
</html>
