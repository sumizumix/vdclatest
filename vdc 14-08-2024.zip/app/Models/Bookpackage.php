<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Bookpackage extends Authenticatable
{
    use HasFactory;
    protected $table="bookpackage";
    protected $fillable = [
        'product_name',
        'name',
        'phone',
        'email'
       
        
    ];
}
