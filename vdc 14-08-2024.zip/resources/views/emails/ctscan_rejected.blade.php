<!DOCTYPE html>
<html>
<head>
    <title>CT Scan  Rejected</title>
</head>
<body>
    <p>Your CT Scan Appointment has been rejected.</p>
</body>
</html>
