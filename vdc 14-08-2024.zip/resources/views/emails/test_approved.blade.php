<!DOCTYPE html>
<html>
<head>
    <title>Test Booking Approved</title>
</head>
<body>
    <p>Your Test Booking has been approved.</p>
</body>
</html>
