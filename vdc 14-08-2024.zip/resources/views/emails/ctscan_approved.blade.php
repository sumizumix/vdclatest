<!DOCTYPE html>
<html>
<head>
    <title>CT Scan Booking Approved</title>
</head>
<body>
    <p>Your CT Scan booking has been approved.</p>
</body>
</html>
