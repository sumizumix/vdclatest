<!DOCTYPE html>
<html>
<head>
    <title>Test Booking  Rejected</title>
</head>
<body>
    <p>Your Test Booking has been rejected.</p>
</body>
</html>
