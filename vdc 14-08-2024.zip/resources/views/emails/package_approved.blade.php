<!DOCTYPE html>
<html>
<head>
    <title>Package Booking Approved</title>
</head>
<body>
    <p>Your booking has been approved.</p>
</body>
</html>
