<!DOCTYPE html>
<html>
<head>
    <title>Package Booking Rejected</title>
</head>
<body>
    <p>Your package booking has been rejected.</p>
</body>
</html>
