<!DOCTYPE html>
<html>
<head>
    <title>Sample Collection Approved</title>
</head>
<body>
    <p>Your sample has been approved.</p>
</body>
</html>
